/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hospital;

/**
 *
 * @author camper
 */
public class pabellon {
    
    private String nombre_pabellon;
    
    public pabellon ( String nombre_pabellon ){
    
    this.nombre_pabellon = nombre_pabellon;
    
    }
    
    
    public String GetNombre(){
        return nombre_pabellon;
        
    }
    
    public void setNombre(String nombre){
    this.nombre_pabellon = nombre_pabellon;
}
    
    
}

